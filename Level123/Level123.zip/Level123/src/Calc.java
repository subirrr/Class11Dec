import java.util.Scanner;

public class Calc {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter 1st number: ");
        double num1 = scanner.nextDouble();

        System.out.print("Enter 2nd number: ");
        double num2 = scanner.nextDouble();

        System.out.print("Enter 3rd number: ");
        double num3 = scanner.nextDouble();

        System.out.print("Enter 4th number: ");
        double num4 = scanner.nextDouble();

        System.out.print("Enter operator (+, -, *, /): ");
        String operator = scanner.next();

        double result;

        if (operator.equals("+")) {
            result = num1 + num2 + num3 + num4;
        } else if (operator.equals("-")) {
            result = num1 - num2 - num3 - num4;
        } else if (operator.equals("*")) {
            result = num1 * num2 * num3 * num4;
        } else if (operator.equals("/")) {
            if (num2 != 0 && num3 != 0 && num4 != 0) {
                result = num1 / num2 / num3 / num4;
            } else {
                System.out.println("Cannot divide by zero");
                scanner.close();
                return;
            }
        } else {
            System.out.println("Invalid operator");
            scanner.close();
            return;
        }

        System.out.println("Result: " + result);

        scanner.close();
    }
}
