import java.util.Scanner;

public class Mapno {
    public static void main(String[] args) {
        System.out.print("Enter day: ");
        Scanner scanner = new Scanner(System.in);
        int map_no = scanner.nextInt();

        String day = "";
        if (map_no == 1) {
            day = "Sunday";
        }
        else if (map_no == 2) {
            day = "Monday";
        }
        else if (map_no == 3) {
            day = "Tuesday";
        }
        else if (map_no == 4) {
            day = "Wednesday";
        }
        else if (map_no == 5) {
            day = "Thursday";
        }
        else if (map_no == 6) {
            day = "Friday";
        }
        else if (map_no == 7) {
            day = "Saturday";
        }
        else {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        System.out.println(day);
        scanner.close();
    }
}
